(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 1445:
/***/ ((module) => {

// Exports
module.exports = {
	"card": "Card_card__QH1mK",
	"cardImgwrapper": "Card_cardImgwrapper__me9Xh",
	"cardImg": "Card_cardImg__dRCn1",
	"cardContent": "Card_cardContent__HBrWP",
	"cardTitle": "Card_cardTitle__YsBSO",
	"cardDescription": "Card_cardDescription__20YUc",
	"moreBtn": "Card_moreBtn__4Nsfh"
};


/***/ }),

/***/ 344:
/***/ ((module) => {

// Exports
module.exports = {
	"wrapper": "Hero_wrapper__EcDEe",
	"moreBtn": "Hero_moreBtn__8rjtL",
	"overlay": "Hero_overlay__g2ZAu",
	"slider": "Hero_slider__ips3l",
	"carousel-slider": "Hero_carousel-slider__8AwCj",
	"control-dots": "Hero_control-dots__K8SJn",
	"dot": "Hero_dot__7TFYh",
	"legend": "Hero_legend__cLUim",
	"links": "Hero_links__MKZC4",
	"carousel-root": "Hero_carousel-root__HrpZV",
	"imageWrapper": "Hero_imageWrapper__mutcC",
	"imgp": "Hero_imgp__GYrUL",
	"img": "Hero_img__Vgook"
};


/***/ }),

/***/ 3579:
/***/ ((module) => {

// Exports
module.exports = {
	"aboutus": "Home_aboutus__J6bca",
	"overlay": "Home_overlay__yE804",
	"content": "Home_content__Zy02X",
	"cards": "Home_cards__mtQuA"
};


/***/ }),

/***/ 6403:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
// EXTERNAL MODULE: ./styles/Home.module.css
var Home_module = __webpack_require__(3579);
var Home_module_default = /*#__PURE__*/__webpack_require__.n(Home_module);
// EXTERNAL MODULE: ./styles/Hero.module.css
var Hero_module = __webpack_require__(344);
var Hero_module_default = /*#__PURE__*/__webpack_require__.n(Hero_module);
// EXTERNAL MODULE: ./node_modules/react-responsive-carousel/lib/styles/carousel.min.css
var carousel_min = __webpack_require__(3559);
;// CONCATENATED MODULE: external "react-responsive-carousel"
const external_react_responsive_carousel_namespaceObject = require("react-responsive-carousel");
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/hero.js





function Hero() {
    return /*#__PURE__*/ jsx_runtime_.jsx("main", {
        className: (Hero_module_default()).wrapper,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: (Hero_module_default()).slider,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_responsive_carousel_namespaceObject.Carousel, {
                infiniteLoop: true,
                autoPlay: true,
                transitionTime: 2000,
                interval: 5000,
                axis: "horizontal",
                showArrows: false,
                showThumbs: false,
                showStatus: false,
                stopOnHover: true,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "/samburu.jpg",
                                alt: "",
                                className: (Hero_module_default()).img
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                className: (Hero_module_default()).legend,
                                children: [
                                    "Visit Samburu National Park.",
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/holidays/0",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: (Hero_module_default()).links,
                                            children: "see more"
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "/hellsgate.jpg",
                                alt: "",
                                className: (Hero_module_default()).img
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                className: (Hero_module_default()).legend,
                                children: [
                                    "1 Day trip to Hellsgate National Park.",
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/holidays/1",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: (Hero_module_default()).links,
                                            children: "see more"
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "/mtkenya.jpg",
                                alt: ""
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                className: (Hero_module_default()).legend,
                                children: [
                                    "Experience the beautiful Mt Kenya National park and Mountain.",
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/holidays/2",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: (Hero_module_default()).links,
                                            children: "see more"
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "/longonot.jpg",
                                alt: "",
                                className: (Hero_module_default()).img
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                className: (Hero_module_default()).legend,
                                children: [
                                    "Hike the majestic Mt longonot.",
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/holidays/3",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: (Hero_module_default()).links,
                                            children: "see more"
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "/aboretum.jpg",
                                alt: "",
                                className: (Hero_module_default()).img
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                className: (Hero_module_default()).legend,
                                children: [
                                    "Loop trail -Nairobi Arboretum.",
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/holidays/4",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: (Hero_module_default()).links,
                                            children: "see more"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    });
}

// EXTERNAL MODULE: ./styles/Card.module.css
var Card_module = __webpack_require__(1445);
var Card_module_default = /*#__PURE__*/__webpack_require__.n(Card_module);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/Card.js




function Card({ item  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (Card_module_default()).card,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (Card_module_default()).cardImgwrapper,
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: `/${item?.image}`,
                    alt: `${item?.title}`,
                    fill: true,
                    className: (Card_module_default()).cardImg
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (Card_module_default()).cardContent,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (Card_module_default()).cardTitle,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            children: item?.title
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: (Card_module_default()).cardDescription,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: item?.description
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: `/holidays/${item?.id}`,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: (Card_module_default()).moreBtn,
                                    children: "More"
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: external "fs"
const external_fs_namespaceObject = require("fs");
var external_fs_default = /*#__PURE__*/__webpack_require__.n(external_fs_namespaceObject);
;// CONCATENATED MODULE: external "path"
const external_path_namespaceObject = require("path");
var external_path_default = /*#__PURE__*/__webpack_require__.n(external_path_namespaceObject);
;// CONCATENATED MODULE: ./pages/index.js







const imageUrls = (/* unused pure expression or super */ null && ([
    "oceanview",
    "cheetahtree",
    "hero"
]));
function Home(props) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "GreenPrint tours and Travel"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "Tour with us"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/logo.jpg"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                className: (Home_module_default()).main,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Hero, {}),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                        className: (Home_module_default()).aboutus,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Home_module_default()).overlay
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (Home_module_default()).content,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Are you a Kenyan national or an expat living in Kenya? We'll help you explore Kenya, the wider eastern Africa, and the rest of the world."
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "We're always ready to serve you. We'll help you book your hotels, book your flight, organize airport transfers, choose the best and most unique destinations for your tours. Anything to make your travel convenient & affordable. This way, you can explore, meet new people & create lasting memories."
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                        children: [
                                            "Reach out to us on ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/contacts",
                                                    style: {
                                                        color: "orange"
                                                    },
                                                    children: "our contacts"
                                                })
                                            }),
                                            " or view our ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/tours",
                                                    style: {
                                                        color: "orange"
                                                    },
                                                    children: "packages"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                style: {
                                    fontWeight: "600",
                                    fontSize: "2rem",
                                    textAlign: "center",
                                    textDecoration: "underline",
                                    marginBlock: "2rem",
                                    color: "orange",
                                    cursor: "pointer"
                                },
                                children: "Upcoming tours & holidays"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Home_module_default()).cards,
                                children: !props ? /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                    children: "loading ..."
                                }) : props.data.upcoming?.map((item, index)=>{
                                    return /*#__PURE__*/ jsx_runtime_.jsx(Card, {
                                        item: item
                                    }, index);
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (Home_module_default()).cards
                            })
                        ]
                    })
                ]
            })
        ]
    });
}


async function getStaticProps() {
    // Read the file contents
    const data = await external_fs_default().promises.readFile(external_path_default().resolve("data.json"));
    // Parse the JSON data
    const jsonData = JSON.parse(data);
    return {
        props: {
            data: jsonData
        }
    };
}


/***/ }),

/***/ 3559:
/***/ (() => {



/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [636,675,664], () => (__webpack_exec__(6403)));
module.exports = __webpack_exports__;

})();